<?php
	$weather="";
	$error="";
  if($_GET['city']){
    $urlContents=file_get_contents("http://api.openweathermap.org/data/2.5/weather?q=".$_GET['city'].",".$_GET['country']."&appid=36d73a2f5106b6ce8397e873987d8ed0");
    $weatherArray=json_decode($urlContents,true);
    $weather="The weather in ".$_GET['city']." is currently ".$weatherArray['weather'][0]['description']."<br>"."";
    $tempInCelsius=$weatherArray['main']['temp']-273;
    $windspeed=$weatherArray['wind']['speed'];
    $weather.=" The temperature is ".$tempInCelsius."&deg;C <br>"."";
    $weather.=" The windspeed is ".$windspeed."mph";
  }
?>





<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Weather App</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/css1.css">
    <style type="text/css">
  		body {
    	background-image:url("images/back.jpg");
    	background-repeat: no-repeat;
    	background-size: 100% 100%;
		}
		html {
    		height: 100%;
            width:100%;
		}
      @media screen and (max-width: 699px) and (min-width: 520px) {
    body {
        padding-left: 30px;
        background: url(email-icon.png) left center no-repeat;
    	}
	}
    </style>
  </head>
  <body>
    <div id="container">
        <h4>What's today's Weather?</h4>
        <form>
          <div class="form-group">
            <label for="exampleFormControlInput1" id="head">Enter the name of a city</label>
            <input type="text" class="form-control" name="city" id="city" placeholder="eg.Kolkata,London" value="<?php echo $_GET['city'];?>">
            <label for="exampleFormControlInput2" id="head">Enter the name of Country</label>
            <input type="text" class="form-control" name="country" id="city" placeholder="eg.India,UK" value="<?php echo $_GET['country'];?>">
            <br>
            <button type="submit" id="b3" class="btn btn-success btn-primary">Submit</button>
          </div>
        </form>
      <?php
      	if($weather)
        {
          echo '<div class="alert alert-success" role="alert" id="display">
  					'.$weather.'
				</div>';
        }
      else if($error){
      echo '<div class="alert alert-danger" role="alert" id="failure">
      			'.$error.'
      			</div>';
      }
      ?>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>